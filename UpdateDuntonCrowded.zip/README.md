# Crowded Webpage

## Background

I built a basic resume webpage based off the information given to me by Crowded.

## Files

When the file is unzipped there should be 2 folders, 1 file and a README. 
* **README.md**
* **index**.**html**
* **js** folder
    * **resume.js**
    * **map.js**
* **css** folder
    * **main.css**
    * **small.css**


## Running the Files

Simply open the **index**.**html** file in your browser. Enjoy!